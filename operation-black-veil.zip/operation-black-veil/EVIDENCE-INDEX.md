# Evidence Index and Data Dictionary

All records are invented. Times ending in `Z` are UTC. `+02:00` is an explicit fictional local-time offset for the supplied timetable.

| File | Contents | Main pivot |
|---|---|---|
| case_brief.txt | Case task, fictional setting, reporting standard | Case BV-17 |
| fieldnote.txt | Recovered handle, phrase, time caution | `sable_wren`, glass orchard |
| account_registry.csv | Three competing synthetic accounts | `handle`, `source_id` |
| profile_archive.json | Archived profile snapshot and linked feed | `linked_feed`, `recovery_hint` |
| forum_posts.json | Three dated synthetic posts | `handle`, `id`, timing/context |
| domain_records.csv | Three fictional historical DNS records | `txt_value`, `archive_ref`, `registrant_code` |
| archive_index.txt | DNS archive cross-reference and recovery hint | `VE-441`, catalog search constraints |
| supplier_register.csv | Fictional supplier-code register | principal and contract |
| print_run_catalog.csv | Three print records, including chronology decoy | title and cover mark |
| photo_manifest.csv | Synthetic image digest and embedded grid claim | SHA-256, grid |
| proof_03.svg | Self-contained schematic, not real geodata | `VG-04 / D7` |
| grid_legend.csv | Fictional grid-to-feature lookup | `VG-04`, `D7` |
| civic_clock_notices.csv | Chime-suppression interval and unrelated decoy | UTC interval |
| transit_timetable.csv | Fictional local arrivals and offsets | North Quay, 22:10 at +02:00 |
| message_fragments.json | Three fragments from training mailbox export | UTC time and planned route |
| procurement_extract.csv | Fictional award and disputed amount | `PC-77`, disputed amount |
| acceptance_log.csv | Two synthetic inspection events | Duplicate image reference |
| identity_crosswalk.csv | Competing identity assertions with confidence labels | High/medium/low source claims |
| SHA256SUMS.txt | SHA-256 of the above evidence files | Integrity verification |

## Interpretation notes

The SVG is a designed training illustration. Its embedded label and manifest are supplied so that basic file inspection works offline; players should still verify the file hash. The grid cell is not a latitude/longitude coordinate. The transit schedule supplies an arrival time, while the clock notice supplies a 20-minute window; the point estimate is the schedule-aligned midpoint. The supplier register identifies a principal in a synthetic record but does not prove who authored the social posts. The procurement discrepancy warrants review, not a conclusive fraud claim.
