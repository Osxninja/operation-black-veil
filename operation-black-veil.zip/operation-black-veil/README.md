# OPERATION BLACK VEIL — Player Brief

**Classification:** Training simulation / all content fictional  
**Estimated effort:** 30 hours  
**Mode:** Offline, evidence-led OSINT  
**Tools:** Any local text, spreadsheet, JSON, image, and metadata viewer. No external services are required.

## Situation

Analyst Mara Venn missed a check-in after sending a cryptic fragment. Recover the recipient identity, reconstruct the meeting, and determine what the meeting was meant to expose. Your evidence set contains deliberate noise, conflicting confidence levels, multiple time zones, a decoy identity, and several independent corroboration paths.

## Rules of evidence

1. Work only from the supplied bundle. All `.test` domains and places are fictional. Do not query real services or attempt to contact anyone.
2. Keep a claim/evidence ledger. Separate direct observation, inference, and confidence. A username match alone is insufficient attribution.
3. Convert local times using the supplied UTC offsets. Never infer a timezone from a location name.
4. Treat correlation as a lead, not proof. Seek independent corroboration and explain contradictions.
5. Submit each stage's answer in the required normalized form. Flags are case-sensitive.

## Deliverable

Complete `ANSWER-SHEET.md`. For each finding, record the answer, supporting file and row/post IDs, reasoning, competing hypothesis, and confidence. Target effort allocations are in `ROOM.md`.

## Evidence index

Start with `evidence/case_brief.txt`. Use `evidence/SHA256SUMS.txt` to verify files. See `evidence/` for offline account, domain, archive, image, geospatial, timetable, communications, procurement, and identity records.

## Candidate worksheet

| Stage | Finding | Evidence IDs | Confidence | Flag |
|---|---|---|---|---|
| 1 | Recovered account handle | | | |
| 2 | Account-linked archive domain | | | |
| 3 | Supplier code | | | |
| 4 | Print-run recovery key | | | |
| 5 | Grid cell / mapped feature | | | |
| 6 | Rendezvous time in UTC | | | |
| 7 | Contract / disputed amount | | | |
| Final | Recipient; location; UTC time; purpose | | | |
