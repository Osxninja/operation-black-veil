# Room Design and Challenge Flow

## Room description (publishable)

A missing analyst left behind a fictional digital trail. Reconstruct an identity, follow an offline archive, interpret a synthetic map and time system, then assess a procurement anomaly. This research-focused OSINT room rewards careful source evaluation, reproducibility, and calibrated confidence. No external internet is used.

## Learning objectives

- Build a source ledger and distinguish identity correlation from attribution.
- Reconcile archived account, domain, registry, and physical-record data.
- Read a synthetic geospatial artifact using its own legend.
- Normalize local civil time to UTC and resolve a scheduled clock anomaly.
- Synthesize independent evidence and report uncertainty without overstating.

## 30-hour pacing plan

| Module | Work | Target |
|---|---|---:|
| 0 | Briefing, evidence handling, integrity checks | 1 h |
| 1 | Account discovery and competing-hypothesis register | 3 h |
| 2 | Domain history and offline archive pivot | 4 h |
| 3 | Supplier and print-run cross-reference | 4 h |
| 4 | Image provenance and grid interpretation | 5 h |
| 5 | Timeline reconstruction; timezone/clock reconciliation | 4 h |
| 6 | Procurement anomaly and identity attribution | 5 h |
| 7 | Final analytic report and peer review | 4 h |
| **Total** | | **30 h** |

## Challenge chain

Submit the requested normalized answer as a flag at each checkpoint. Exact accepted strings are maintained in the restricted instructor key.

| # | Question | Skill and dependency |
|---|---|---|
| 1 | Identify the recovered account handle linked to the repeated phrase. | Correlate field note, account registry, and archived profile; reject alternatives. |
| 2 | Identify the archived domain connected to the account routing label. | Join profile feed to DNS record and follow its archive reference. |
| 3 | Find the supplier code that bridges archive metadata and the procurement register. | Cross-reference the archive index with the supplier register. |
| 4 | Determine the print-run key indicated by the recovery hint. | Apply both constraints in the hint to the print catalog. |
| 5 | Report the grid and cell containing the relevant meeting feature. | Read the image's own grid and look up its legend. |
| 6 | Estimate the planned meeting time in UTC. | Reconcile communications, clock notice, local timetable, and UTC offset. |
| 7 | Identify the contract and disputed amount. | Distinguish the award total from the disputed amount; use acceptance records. |
| 8 | Submit the final analytic assessment: intended recipient, location, UTC time, and purpose. | Synthesize independent sources and state confidence and limitations. |

## Research standard

Stages 1–7 are extraction/correlation checkpoints, not proof of the final claim. Final attribution must weigh high, medium, and low confidence records. A defensible report says the records support Rusk as intended recipient; the bundle does not prove Venn reached the meeting or that Rusk personally authored every linked post.
